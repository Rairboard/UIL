public class Birthday
{

    public static void main(String[] args)
    {
        System.out.println("    i i i i i i");
        System.out.println("   +-----------+");
        System.out.println("   |:::::::::::|");
        System.out.println("   |:H:a:p:p:y:|");
        System.out.println("   |:::::::::::|");
        System.out.println(" __%%%%%%%%%%%%%__");
        System.out.println("|^^^^^^^^^^^^^^^^^|");
        System.out.println("|:B:i:r:t:h:d:a:y:|");
        System.out.println("|:::::::::::::::::|");
        System.out.println("%%%%%%%%%%%%%%%%%%%");
    }
}

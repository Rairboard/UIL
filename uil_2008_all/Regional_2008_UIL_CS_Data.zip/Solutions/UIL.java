import java.util.*;
import java.io.*;
import static java.lang.System.*;


public class UIL {

	public static void main(String args[]) throws IOException
	{
		for(int i=0; i<18; i++) 
			out.println("UU    UU   II   LL");
		out.println("UUUUUUUU   II   LLLLLL");
		out.println("UUUUUUUU   II   LLLLLL");			
	}	
}

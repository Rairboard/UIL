// UIL 2007 - District A Hands-On Programming Contest
//
// display.java
//
// This problem tests contestant ability to write a Java
// program that will compile and run successfully.
//

import java.io.*;
import java.util.*;

public class display {
   
   public static void main (String args[]) throws IOException {

      System.out.println("This is the current display.");

   }
}

// UIL 2007 - District B Hands-On Programming Contest
//
// sign.java
//
// This problem tests contestant ability to write a Java
// program that will compile and run successfully.
//

import java.io.*;
import java.util.*;

public class sign {
   
   public static void main (String args[]) throws IOException {

      System.out.println("Left lane closed ahead.");

   }
}

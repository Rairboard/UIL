// UIL 2006 - State Programming Contest
//
// print.java
//
// PURPOSE: Shows that teams can submit a program that
// compiles and runs successfully.
//

import java.io.*;
import java.util.*;


public class print {
   
   public static void main (String args[]) {

      System.out.println("This problem has no input.");
      System.out.println("It just has output.");

   }
}

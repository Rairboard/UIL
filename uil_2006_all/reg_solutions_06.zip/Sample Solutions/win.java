// UIL 2006 - Regional Programming Contest
//
// win.java
//
// The purpose of this problem is to test contestant
// ability to use loops.
//

import java.io.*;
import java.util.*;

public class win {
   
   public static void main (String args[]) throws IOException {
   
      for (int i=0; i<27356; i++)
      {
         System.out.println("I want to win!");
      }
      
   }

}
